<?php
/**
 * Dropbox Auth API Credentials
 *
 * @package BackupBuddy
 */

return array(
	'DROPBOX_API_KEY'      => 'zgbx8f8dy7rr8ot',
	'DROPBOX_API_SECRET'   => 'xjixvj1uc2dvvir',
	'DROPBOX_REDIRECT_URI' => 'https://oauth-redirect.ithemes.com/dropbox/auth',
);
