<?php

namespace LivemeshAddons\Blocks\Headers;

class LAE_Block_Header_1 extends LAE_Block_Header {

    function get_block_header_class() {

        return 'lae-block-header-1';

    }
}