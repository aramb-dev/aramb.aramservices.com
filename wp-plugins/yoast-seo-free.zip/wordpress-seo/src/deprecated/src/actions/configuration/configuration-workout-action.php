<?php

namespace Yoast\WP\SEO\Actions\Configuration;

/**
 * Class Configuration_Workout_Action.
 *
 * @deprecated 19.0 - Use \Yoast\WP\SEO\Actions\First_Time_Configuration_Action instead.
 * @codeCoverageIgnore
 */
class Configuration_Workout_Action extends First_Time_Configuration_Action {}
