<?php

namespace LivemeshAddons\Blocks\Headers;

class LAE_Block_Header_7 extends LAE_Block_Header_6 {

    function get_block_header_class() {

        return 'lae-block-header-expanded lae-block-header-7';

    }
}