== Changelog ==

= 3.0.0 - 2020-11-09 =
* BugFix: Warnings from console.
* BugFix: Update error/success message strings.
* New Feature: Introduce Bulk Action for Attempts.
* Enhancement: Optimize UI/UX for WP-Admin Settings.
* Enhancement: Optimize plugin speed and code improvement.
* Compatibility: LoginPress - Limit Login Attempts is compatible with WooCommerce Login Account.
* Compatibility: LoginPress - Limit Login Attempts is compatible with LoginPress - Hide Login Add-On.
* Compatibility: LoginPress - Limit Login Attempts is compatible with TranslatePress plugin.

= 2.0.0 - 2020-06-24 =
* BugFix: Time Stamp Correction according to WordPress Time Zone.
* New Feature: Manually IP add in White and Black List.
* New Feature: XML Request Control.
* Enhancement: New Translation files generated.

= 1.2.2 - 2020-01-16 =
* Compatibility: LoginPress - Limit Login Attempts is compatible with Portuguese (Brazil) language now.
* Compatibility: LoginPress - Limit Login Attempts is compatible with French language now.

= 1.2.1 - 2019-10-23 =
* BugFix: Typo in error messages.

= 1.2.0 - 2019-08-10 =
* BugFix: Remove JS warnings.
* Enhancement: Important Security update.
* Enhancement: Code refactoring.
* Compatibility: LoginPress - Limit Login Attempts is compatible with Arabic language now.

= 1.1.1 - 2019-07-16 =
* Enhancement: Create POEdit file.

= 1.1.0 - 2019-07-08 =
* Enhancement: Important Security update.
* Enhancement: Update Search Layout.
* Enhancement: Compatible with Multisite.

= 1.0.0 - 2018-01-08 =
* Initial Launch.

= 1.0.0-beta - 2017-12-22 =
* Beta Launch.
