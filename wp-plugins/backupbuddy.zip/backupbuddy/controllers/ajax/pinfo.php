<?php
/**
 * Server info page extended PHPinfo thickbox.
 * Server info page phpinfo button.
 *
 * @package BackupBuddy
 */

backupbuddy_core::verifyAjaxAccess();

phpinfo();

die();
