<?php

if(!class_exists('aws')){
	include_once __DIR__ . '/aws.php';
}

final class caws extends aws{
	
	//Don't need to do anything here as the aws class will handle the rest

}

