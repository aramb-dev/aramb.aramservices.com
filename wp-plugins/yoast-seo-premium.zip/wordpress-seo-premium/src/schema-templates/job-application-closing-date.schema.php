<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-application-closing-date" only-nested=true recommended-for=[ "yoast/job-posting" ] }}
{{attribute name="closingDate"}}
