<?php
if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

/**
* Handling all the AJAX calls in LoginPress - Limit Login Attempts.
*
* @since 1.0.0
* @version 2.0.1
* @class LoginPress_Attempts_AJAX
*/

if ( ! class_exists( 'LoginPress_Attempts_AJAX' ) ) :

	class LoginPress_Attempts_AJAX {

		/**
	  * Variable for LoginPress Limit Login Attempts table name.
	  *
	  * @var string
	  * @since 2.1.0
	  */
	  protected $llla_table;

		/*
		* * * * * * * * *
		* Class constructor
		* * * * * * * * * */
		public function __construct() {

			global $wpdb;
			$this->llla_table = $wpdb->prefix . 'loginpress_limit_login_details';
			$this->init();
		}
		public function init() {

			$ajax_calls = array(
				'attempts_whitelist'  => false,
				'attempts_blacklist'  => false,
				'attempts_unlock'     => false,
				'whitelist_clear'     => false,
				'blacklist_clear'     => false,
				'white_black_list_ip' => false,
				'white_list_records'  => false,
				'black_list_records'  => false,
				'attempts_bulk'       => false,
			);

			foreach ( $ajax_calls as $ajax_call => $no_priv ) {
				// code...
				add_action( 'wp_ajax_loginpress_' . $ajax_call, array( $this, $ajax_call ) );

				if ( $no_priv ) {
					add_action( 'wp_ajax_nopriv_loginpress_' . $ajax_call, array( $this, $ajax_call ) );
				}
			}
		}

		/**
		 * Update Attempts status with respect to the Bulk Action.
		 * @since 2.1.0
		 * @return array Updated IP address
		 */
		public function attempts_bulk() {

			check_ajax_referer( 'loginpress-llla-bulk-nonce', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			$action = sanitize_text_field( $_POST['bulk_action'] );
			$ips    = array_unique( $_POST['bulk_ips'] );

			switch ( $action ) {
				case 'unlock':
					foreach ( $ips as $ip ) :
						$this->llla_delete_meta( $ip );
					endforeach;
				break;
				case 'white_list':
					foreach ( $ips as $ip ) :
						$this->llla_update_meta( 'whitelist', $ip );
					endforeach;
				break;
				case 'black_list':
					foreach ( $ips as $ip ) :
						$this->llla_update_meta( 'blacklist', $ip );
					endforeach;
				break;
			}

			wp_send_json_success(
				[
					'message'     => __( 'IP status updated.', 'loginpress_pro' ),
					'updated_ips' => $ips,
				]
			);
			wp_die();
		}

		/**
		 * Move Attempted IP into Whitelist.
		 * @return void
		 * @since 1.0.0
		 * @version 2.1.0
		 */
		public function attempts_whitelist() {

			check_ajax_referer( 'loginpress-user-llla-nonce', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			$id    = $_POST['id'];
			$ip    = $_POST['ip'];

			$this->llla_update_meta( 'whitelist', $ip );
			wp_die();

		}

		/**
		 * Move Attempted IP into Blacklist.
		 * @return void
		 * @since 1.0.0
		 * @version 2.1.0
		 */
		public function attempts_blacklist() {

			check_ajax_referer( 'loginpress-user-llla-nonce', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			$id    = $_POST['id'];
			$ip    = $_POST['ip'];

			$this->llla_update_meta( 'blacklist', $ip );
			wp_die();
		}

		/**
		 * Remove Attempted IP from DataBase record.
		 * @return void
		 * @since 1.0.0
		 * @version 2.1.0
		 */
		public function attempts_unlock() {

			check_ajax_referer( 'loginpress-user-llla-nonce', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			$id    = $_POST['id'];
			$ip    = $_POST['ip'];

			$this->llla_delete_meta( $ip );
			wp_die();
		}

		/**
		 * Remove Whitelisted IP from DataBase record.
		 * @return string
		 * @since 1.0.0
		 * @version 2.1.0
		 */
		public function whitelist_clear() {

			check_ajax_referer( 'loginpress-user-llla-nonce', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			$ip    = $_POST['ip'];

			$this->llla_delete_meta( $ip );
			echo 'Whitelist User Deleted';
			wp_die();
		}

		/**
		 * Remove Blacklisted IP from DataBase record.
		 * @return string
		 * @since 1.0.0
		 * @version 2.1.0
		 */
		public function blacklist_clear() {

			check_ajax_referer( 'loginpress-user-llla-nonce', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			$ip    = $_POST['ip'];

			$this->llla_delete_meta( $ip );
			echo 'Blacklist User is Deleted';
			wp_die();
		}

		/**
		 * Black list or White list an IP address Manually through settings page.
		 * @since 2.0.0
		 * @return void
		 */
		public function white_black_list_ip() {

			$current_time = current_time( 'timestamp' );
			check_ajax_referer( 'ip_add_remove', 'security' );

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			global $wpdb;
			$ip     = $_POST['ip'];
			$action = sanitize_text_field( $_POST['ip_action'] );

			if ( empty( $ip ) ) {
				wp_send_json_error( [ 'message' => __( 'IP is required field.', 'loginpress-limit-login-attempts' ) ] );
			}

			if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				wp_send_json_error( [ 'message' => __( 'Your IP format is not correct.', 'loginpress-limit-login-attempts' ) ] );
			}

			$exist_record = $wpdb->get_results( "SELECT * FROM $this->llla_table WHERE ip = '$ip' limit 1" );

			if ( 'white_list' === $action ) {

				if ( count( $exist_record ) && '1' !== $exist_record[0]->whitelist ) {

					$wpdb->query( $wpdb->prepare( "UPDATE `{$this->llla_table}` SET `whitelist` = '1' , `blacklist` = '0', `gateway` = 'Manually' WHERE ip = %s", $ip ) );
					wp_send_json_success(
						[
							'message' => __( 'IP Address already exist, Successfully moved from blacklist to whitelist.', 'loginpress-limit-login-attempts' ),
							'action'  => 'move_black_to_white',
						]
					);
				}

				if ( count( $exist_record ) < 1 ) {
					$wpdb->query( $wpdb->prepare( "INSERT INTO {$this->llla_table} (ip,whitelist,datentime,gateway) values (%s,%s,%s,%s)", $ip, '1', $current_time, 'Manually' ) );
					wp_send_json_success(
						[
							'message' => __( 'Successfully IP Address added in white list.', 'loginpress-limit-login-attempts' ),
							'action'  => 'new_whitelist',
						]
					);
				}

				wp_send_json_success(
					[
						'message' => __( 'IP Address already exists in whitelist.', 'loginpress-limit-login-attempts' ),
						'action'  => 'already_whitelist',
					]
				);

			}
			if ( 'black_list' === $action ) {

				if ( count( $exist_record ) && '1' !== $exist_record[0]->blacklist ) {

					$wpdb->query( $wpdb->prepare( "UPDATE `{$this->llla_table}` SET `whitelist` = '0' , `blacklist` = '1', `gateway` = 'Manually' WHERE ip = %s", $ip ) );
					wp_send_json_success(
						[
							'message' => __( 'IP Address already exist, Successfully moved from whitelist to blacklist.', 'loginpress-limit-login-attempts' ),
							'action'  => 'move_white_to_black',
						]
					);
				}

				if ( count( $exist_record ) < 1 ) {
					$wpdb->query( $wpdb->prepare( "INSERT INTO {$this->llla_table} (ip,blacklist,datentime,gateway) values (%s,%s,%s,%s)", $ip, '1', $current_time, 'Manually' ) );
					wp_send_json_success(
						[
							'message' => __( 'Successfully IP Address added in blacklist.', 'loginpress-limit-login-attempts' ),
							'action'  => 'new_blacklist',
						]
					);
				}

				wp_send_json_success(
					[
						'message' => __( 'IP Address already exists in blacklist.', 'loginpress-limit-login-attempts' ),
						'action'  => 'already_blacklist',
					]
				);

			}
			wp_die();
		}
		/**
		 * Get whitelist records.
		 *
		 * @return void
		 */
		public function white_list_records() {

			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'No cheating, huh!' );
			}

			global $wpdb;
			$mywhitelist = $wpdb->get_results( "SELECT DISTINCT ip,whitelist FROM {$this->llla_table} WHERE `whitelist` = 1" );
			$html        = '';
			if ( $mywhitelist ) {
				$loginpress_user_wl_nonce = wp_create_nonce( 'loginpress-user-llla-nonce' );
				foreach ( $mywhitelist as $whitelist ) {
					$html .= '<tr>';
					$html .= '<td data-whitelist-ip="' . $whitelist->ip . '">' . $whitelist->ip . '</td>';
					$html .= '<td><input class="loginpress-whitelist-clear button button-primary" type="button" value="Clear" /><input type="hidden" class="loginpress__user-wl_nonce" name="loginpress__user-wl_nonce" value="' . $loginpress_user_wl_nonce . '"></td>';
					$html .= '</tr>';
				}
				wp_send_json_success( [ 'tbody' => $html ] );
			} else {
				wp_send_json_error( [ 'message' => 'record not found' ] );
			}
		}

		/**
		 * Get blacklist records.
		 *
		 * @return void
		 */
		public function black_list_records() {
			global $wpdb;
			$myblacklist = $wpdb->get_results( "SELECT DISTINCT ip,blacklist FROM {$this->llla_table} WHERE `blacklist` = 1" );

			if ( $myblacklist ) {
				$loginpress_user_bl_nonce = wp_create_nonce( 'loginpress-user-llla-nonce' );
				$html                     = '';
				foreach ( $myblacklist as $blacklist ) {
					$html .= '<tr>';
					$html .= '<td>' . $blacklist->ip . '</td>';
					$html .= '<td><input class="loginpress-blacklist-clear button button-primary" type="button" value="Clear" /><input type="hidden" class="loginpress__user-bl_nonce" name="loginpress__user-bl_nonce" value="' . $loginpress_user_bl_nonce . '"></td>';
					$html .= '</tr>';
				}
				wp_send_json_success( [ 'tbody' => $html ] );
			} else {
				wp_send_json_error( [ 'message' => 'record not found' ] );
			}
		}

		/**
		 * Update query.
		 * @param  string $column [Name of the column]
		 * @param  string $ip     [IP Address]
		 * @since 2.1.0
		 */
		public function llla_update_meta( $column, $ip ) {

			if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) :
				return __( 'Your IP format is not correct.', 'loginpress-limit-login-attempts' );
			endif;

			global $wpdb;
			$wpdb->query( $wpdb->prepare( "UPDATE `{$this->llla_table}` SET `{$column}` = '1' WHERE `ip` = %s", $ip ) );
		}

		/**
		 * Delete query.
		 * @param  string $ip [IP Address]
		 * @since 2.1.0
		 */
		public function llla_delete_meta( $ip ) {

			if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) :
				return __( 'Your IP format is not correct.', 'loginpress-limit-login-attempts' );
			endif;

			global $wpdb;
			$wpdb->query( $wpdb->prepare( "DELETE FROM `{$this->llla_table}` WHERE `ip` = %s", $ip ) );
		}

	}

endif;
new LoginPress_Attempts_AJAX();
